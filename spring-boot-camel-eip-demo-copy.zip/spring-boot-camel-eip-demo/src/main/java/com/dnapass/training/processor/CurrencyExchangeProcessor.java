package com.dnapass.training.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.dnapass.training.model.CurrencyExchange;

@Component
public class CurrencyExchangeProcessor {

	Logger logger = LoggerFactory.getLogger(CurrencyExchangeProcessor.class);

	public void processMessage(CurrencyExchange currencyExchange) {

		logger.info("Do some processing wiht currencyExchange.getConversionMultiple() value which is {}",
				currencyExchange.getConversionMultiple() );

	}
}
