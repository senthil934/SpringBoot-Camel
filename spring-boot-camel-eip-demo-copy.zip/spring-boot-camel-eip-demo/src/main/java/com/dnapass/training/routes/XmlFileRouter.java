package com.dnapass.training.routes;

import org.apache.camel.builder.RouteBuilder;
//import org.apache.camel.converter.crypto.CryptoDataFormat;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dnapass.training.model.CurrencyExchange;
import com.dnapass.training.processor.CurrencyExchangeProcessor;
import com.dnapass.training.transformer.CurrencyExchangeTransformer;

//@Component
public class XmlFileRouter extends RouteBuilder {

	@Autowired
	private CurrencyExchangeProcessor myCurrencyExchangeProcessor;

	@Autowired
	private CurrencyExchangeTransformer myCurrencyExchangeTransformer;

	@Override
	public void configure() throws Exception {

		configure6();

	}

	

	public void configure4() throws Exception {
		from("file:files/input/xml?move=done")
		.unmarshal()
		.jacksonxml(CurrencyExchange.class)
		.log("${body}");
		//.to("file:files/output/xml");
	}

	public void configure5() throws Exception {

		from("file:files/input/xml?move=done")
		.unmarshal()
		.jacksonxml(CurrencyExchange.class)
		.bean(myCurrencyExchangeProcessor)
		.log("${body}");
		//.to("file:files/output/xml");
	}

	public void configure6() throws Exception {
		from("file:files/input/xml?move=done")
		.unmarshal()
		.jacksonxml(CurrencyExchange.class)
		.bean(myCurrencyExchangeProcessor)
		.bean(myCurrencyExchangeTransformer)
		.log("${body}");
		//.to("file:files/output/xml");
	}

}
