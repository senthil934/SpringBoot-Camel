package com.dnapass.training.routes;

import java.io.IOException;
import java.math.BigDecimal;
import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import org.apache.camel.builder.RouteBuilder;
//import org.apache.camel.converter.crypto.CryptoDataFormat;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dnapass.training.model.CurrencyExchange;
import com.dnapass.training.processor.CurrencyExchangeProcessor;
import com.dnapass.training.transformer.CurrencyExchangeTransformer;

//@Component
public class JsonFileRouter extends RouteBuilder {

	@Autowired
	private CurrencyExchangeProcessor myCurrencyExchangeProcessor;

	@Autowired
	private CurrencyExchangeTransformer myCurrencyExchangeTransformer;

	@Override
	public void configure() throws Exception {

	configure3();

	}

	public void configure1() throws Exception {

		from("file:files/input/json?move=done")
		.unmarshal()
		.json(JsonLibrary.Jackson, CurrencyExchange.class)				
		.log("${body}");
		//.to("file:files/output/json");

	}

	public void configure2() throws Exception {

		from("file:files/input/json?move=done")
		.unmarshal()
		.json(JsonLibrary.Jackson, CurrencyExchange.class)
		.bean(myCurrencyExchangeProcessor)				
		.log("${body}");
		//.to("file:files/output/json");

	}

	public void configure3() throws Exception {

		from("file:files/input/json?move=done")
		.unmarshal()
		.json(JsonLibrary.Jackson, CurrencyExchange.class)
		.bean(myCurrencyExchangeProcessor)
		.bean(myCurrencyExchangeTransformer)			
		.log("${body}");
		//.to("file:files/output/json");

	}

}




