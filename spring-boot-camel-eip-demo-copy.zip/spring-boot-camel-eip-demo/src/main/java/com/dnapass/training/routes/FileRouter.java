package com.dnapass.training.routes;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class FileRouter extends RouteBuilder {

	@Override
	public void configure() throws Exception {
		// Pipeline
		configure5();
	}

	private void configure1() {
		//The File component provides access to file systems, allowing files to be processed 
		//by any other Camel Components or messages from other components to be saved to disk.
		from("file:files/input/csv")
		.log(" ${file:name}")
		.to("file:files/output/csv");
	}

	private void configure2() {
		from("file:files/input/csv")
		.log(" ${file:name}")
		.process( new FileProcessor())
		.to("file:files/output/csv");

	}
	
	private void configure3() {
		from("file:files/input/csv?move=done")
		.log(" ${file:name}")
		.process( new FileProcessor())
		.to("file:files/output/csv");

	}
	
	
	private void configure5() {
		from("file:files/input/csv?preMove=inprogress&move=done")
		.log(" ${file:name}")
		.process( new FileProcessor())
		.to("file:files/output/csv");

	}

}

class FileProcessor implements Processor {
	public void process(Exchange exchange) throws Exception {
		String originalFileName = (String) exchange.getIn().getHeader(Exchange.FILE_NAME, String.class);

		Date date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
		String changedFileName = originalFileName + dateFormat.format(date)  ;
		exchange.getIn().setHeader(Exchange.FILE_NAME, changedFileName);
	}
}
