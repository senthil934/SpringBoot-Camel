package com.dnapass.training.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.crypto.password.Pbkdf2PasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
public class SpringSecurityConfig extends WebSecurityConfigurerAdapter {

	// Creating just 2 users for demonstration

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {

		auth.inMemoryAuthentication()
				// .passwordEncoder(NoOpPasswordEncoder.getInstance())
				.withUser("user").password("{noop}password").roles("USER")
				.and()
				.withUser("admin").password("{noop}password").roles("USER", "ADMIN");

	}

	//@Bean
	public static PasswordEncoder passwordEncoder() {
		//simple hash algorithms like SHA-256 or MD5
		// return (NoOpPasswordEncoder) NoOpPasswordEncoder.getInstance();
		// return new BCryptPasswordEncoder();
		// return new SCryptPasswordEncoder()
		// return new Argon2PasswordEncoder()
		return new Pbkdf2PasswordEncoder();
	}

	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers("/resources/**");
	}

	// Securing the endpoints with HTTP Basic authentication //
	@Override
	protected void configure(HttpSecurity http) throws Exception {

		http
				// .sessionManagement().sessionFixation().migrateSession()
				// .headers()
				// .frameOptions(); //clickjacking
				// .xssProtection()
				// .and()
				// .contentSecurityPolicy("script-src 'self'");
				// HTTP Basic authentication
		       // .sessionManagement()
		       // .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
		       // .and()
				.httpBasic()						
				.and()
				.authorizeRequests()
				.antMatchers(HttpMethod.GET, "/api/employees").hasRole("USER")
				.antMatchers(HttpMethod.POST, "/api/employees").hasRole("ADMIN")
				.antMatchers(HttpMethod.DELETE, "/api/employees").hasRole("ADMIN") //
				//.antMatchers("/registration").permitAll()
				//.anyRequest().authenticated()
				.and()
				.csrf().disable()
				.formLogin();
				//.and()
				//.logout().logoutRequestMatcher(new AntPathRequestMatcher("/logout"))		;// .disable();
				// .loginUrl("/login")
				// .permitAll();

	}

}
