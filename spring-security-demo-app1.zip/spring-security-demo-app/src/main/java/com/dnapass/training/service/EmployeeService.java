package com.dnapass.training.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.dnapass.training.model.Employee;

@Service
public class EmployeeService {
	static List<Employee> empList = null;
	static {
		empList = new ArrayList<>();
		empList.add(new Employee(101, "employee1", "dept1", "location1"));
		empList.add(new Employee(102, "employee2", "dept1", "location2"));
		empList.add(new Employee(103, "employee3", "dept1", "location3"));
	}

	public List<Employee> findAll() {
		return empList;
	}

	public void save(Employee newEmployee) {
		empList.add(newEmployee);
		System.out.println("saving new employee");

	}

	public void deleteEmpById(Integer id) {
		Employee employee = empList.stream().filter(emp -> emp.getEmpId() == id).findAny().orElse(null);
		empList.remove(employee);
		System.out.println("Employee with " + id + " is deleted");
	}

}
