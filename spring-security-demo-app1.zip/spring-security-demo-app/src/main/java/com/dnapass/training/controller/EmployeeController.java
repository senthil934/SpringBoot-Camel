package com.dnapass.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.dnapass.training.model.Employee;
import com.dnapass.training.service.EmployeeService;

@RestController
@RequestMapping("api")
public class EmployeeController {

	@Autowired
	EmployeeService empService;

	// Get all Employees
	@GetMapping("/employees")
	List<Employee> findAll() {
		return empService.findAll();
	}

	// Save Employees
	@PostMapping("/employees")
	@ResponseStatus(HttpStatus.CREATED)
	String newEmployee(@RequestBody Employee newEmployee) {

		empService.save(newEmployee);
		return "Success fully created Employees";
	}

	// Delete Employees with id
	@DeleteMapping("/employees/{id}")
	String deleteBook(@PathVariable Integer id) {

		empService.deleteEmpById(id);
		return "deleted employee with id " + id + " successfully";
	}
}
